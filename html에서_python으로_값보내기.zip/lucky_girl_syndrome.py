from flask import Flask, request, jsonify,render_template

app = Flask(__name__)

@app.route('/')
def index():
    # index.html 파일을 렌더링하여 클라이언트에게 반환
    return render_template('index.html')

@app.route('/process_data', methods=['POST'])
def process_data():
    data = request.json
    received_data = data.get('data')
    # 받은 데이터를 터미널에 출력
    print("Received data:", received_data)
    print(type(received_data))
    with open("shared_value.txt", "w") as a:
        a.write(str(received_data))

    return jsonify({'message': 'Data received successfully'})

if __name__ == '__main__':
    app.run(debug=True)
