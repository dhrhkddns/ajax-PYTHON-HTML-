const fs = require('fs');

fs.readFile('text.txt','utf8', (err,data) => {
    if(err){
        console.error(err);
        return;
    }
    console.log(data);
});

const content = "happend!!";

fs.appendFile('text.txt', content, err => {
    if(err){
        console.err;
        return;
    }
});