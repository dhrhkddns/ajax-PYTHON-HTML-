export*from"lit-html/async-directive.js";
//# sourceMappingURL=async-directive.js.map
