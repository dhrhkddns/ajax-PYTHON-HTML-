export*from"@lit/reactive-element/decorators/query.js";
//# sourceMappingURL=query.js.map
