export*from"@lit/reactive-element/decorators/event-options.js";
//# sourceMappingURL=event-options.js.map
