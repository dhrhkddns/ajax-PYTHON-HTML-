export*from"@lit/reactive-element/decorators/property.js";
//# sourceMappingURL=property.js.map
