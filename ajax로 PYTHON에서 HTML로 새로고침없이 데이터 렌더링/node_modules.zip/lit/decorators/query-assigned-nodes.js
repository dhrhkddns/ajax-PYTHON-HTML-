export*from"@lit/reactive-element/decorators/query-assigned-nodes.js";
//# sourceMappingURL=query-assigned-nodes.js.map
