export*from"@lit/reactive-element/decorators/query-async.js";
//# sourceMappingURL=query-async.js.map
