export*from"lit-html/directive.js";
//# sourceMappingURL=directive.js.map
