export*from"lit-html/directives/unsafe-svg.js";
//# sourceMappingURL=unsafe-svg.js.map
