export*from"lit-html/directives/class-map.js";
//# sourceMappingURL=class-map.js.map
