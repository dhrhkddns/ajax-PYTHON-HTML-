export*from"lit-html/directives/guard.js";
//# sourceMappingURL=guard.js.map
