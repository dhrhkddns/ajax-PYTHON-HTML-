export*from"lit-html/directives/if-defined.js";
//# sourceMappingURL=if-defined.js.map
