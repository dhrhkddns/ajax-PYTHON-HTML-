export*from"lit-html/directives/choose.js";
//# sourceMappingURL=choose.js.map
