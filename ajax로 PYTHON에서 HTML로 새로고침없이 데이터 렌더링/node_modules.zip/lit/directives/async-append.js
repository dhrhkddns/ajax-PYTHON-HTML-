export*from"lit-html/directives/async-append.js";
//# sourceMappingURL=async-append.js.map
