export*from"lit-html/directives/async-replace.js";
//# sourceMappingURL=async-replace.js.map
