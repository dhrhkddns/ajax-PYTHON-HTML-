export*from"lit-html/directives/live.js";
//# sourceMappingURL=live.js.map
