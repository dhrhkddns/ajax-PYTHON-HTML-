export*from"lit-html/directives/style-map.js";
//# sourceMappingURL=style-map.js.map
