export*from"lit-html/directives/template-content.js";
//# sourceMappingURL=template-content.js.map
