export*from"lit-html/directives/when.js";
//# sourceMappingURL=when.js.map
