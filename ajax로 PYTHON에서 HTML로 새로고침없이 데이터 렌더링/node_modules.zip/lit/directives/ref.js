export*from"lit-html/directives/ref.js";
//# sourceMappingURL=ref.js.map
