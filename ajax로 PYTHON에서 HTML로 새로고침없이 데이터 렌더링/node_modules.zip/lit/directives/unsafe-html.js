export*from"lit-html/directives/unsafe-html.js";
//# sourceMappingURL=unsafe-html.js.map
