export*from"lit-html/directives/cache.js";
//# sourceMappingURL=cache.js.map
