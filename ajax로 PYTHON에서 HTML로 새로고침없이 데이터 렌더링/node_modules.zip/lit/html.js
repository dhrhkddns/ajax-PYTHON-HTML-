export*from"lit-html";
//# sourceMappingURL=html.js.map
