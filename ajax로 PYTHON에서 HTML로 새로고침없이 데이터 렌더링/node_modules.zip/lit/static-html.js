export*from"lit-html/static.js";
//# sourceMappingURL=static-html.js.map
