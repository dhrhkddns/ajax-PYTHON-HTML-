/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import 'lit-element/polyfill-support.js';
//# sourceMappingURL=polyfill-support.js.map