/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from 'lit-html/directives/unsafe-svg.js';
//# sourceMappingURL=unsafe-svg.d.ts.map