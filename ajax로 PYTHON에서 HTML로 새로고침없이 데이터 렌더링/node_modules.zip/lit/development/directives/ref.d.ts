/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from 'lit-html/directives/ref.js';
//# sourceMappingURL=ref.d.ts.map