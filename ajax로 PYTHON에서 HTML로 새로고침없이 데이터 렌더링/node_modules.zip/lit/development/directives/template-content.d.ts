/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from 'lit-html/directives/template-content.js';
//# sourceMappingURL=template-content.d.ts.map