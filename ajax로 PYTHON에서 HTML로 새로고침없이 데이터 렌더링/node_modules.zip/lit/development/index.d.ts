/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import '@lit/reactive-element';
import 'lit-html';
export * from 'lit-element/lit-element.js';
export * from 'lit-html/is-server.js';
//# sourceMappingURL=index.d.ts.map