/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from '@lit/reactive-element/decorators/query-assigned-elements.js';
//# sourceMappingURL=query-assigned-elements.js.map