/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
/**
 * LitElement support for hydration of content rendered using lit-ssr.
 *
 * @packageDocumentation
 */
export * from 'lit-element/experimental-hydrate-support.js';
//# sourceMappingURL=experimental-hydrate-support.d.ts.map