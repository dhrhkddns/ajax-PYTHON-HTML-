/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export {};
//# sourceMappingURL=experimental-hydrate-support.d.ts.map