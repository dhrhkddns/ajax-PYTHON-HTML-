/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
export * from '@lit/reactive-element';
export * from 'lit-html';
export * from './lit-element.js';
export * from './decorators.js';
//# sourceMappingURL=index.d.ts.map