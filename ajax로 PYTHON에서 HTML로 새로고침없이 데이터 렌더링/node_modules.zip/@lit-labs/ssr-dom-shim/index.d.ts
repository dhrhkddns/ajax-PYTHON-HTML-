export { ariaMixinAttributes, ElementInternals, HYDRATE_INTERNALS_ATTR_PREFIX, } from './lib/element-internals.js';
declare const ElementShimWithRealType: {
    new (): Element;
    prototype: Element;
};
export { ElementShimWithRealType as Element };
declare const HTMLElementShimWithRealType: {
    new (): HTMLElement;
    prototype: HTMLElement;
};
export { HTMLElementShimWithRealType as HTMLElement };
declare const CustomElementRegistryShimWithRealType: {
    new (): CustomElementRegistry;
    prototype: CustomElementRegistry;
};
export { CustomElementRegistryShimWithRealType as CustomElementRegistry };
export declare const customElements: CustomElementRegistry;
//# sourceMappingURL=index.d.ts.map